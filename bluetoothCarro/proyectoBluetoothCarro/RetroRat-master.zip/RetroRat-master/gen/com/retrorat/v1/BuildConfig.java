/** Automatically generated file. DO NOT MODIFY */
package com.retrorat.v1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}